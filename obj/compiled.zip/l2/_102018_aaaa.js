/// <mls shortName="aaaa" project="102018" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '_100554_/l2/stateLitElement';
import { exec } from "_102019_/l2/layer1Exec";
let Aaaa102018 = class Aaaa102018 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.name = 'Somebody';
    }
    async firstUpdated() {
        const req = {
            action: 'MDMGetList',
            inDeveloped: true,
            version: '1',
            params: { filter: '1001' }
        };
        const mdm = await exec(req);
        console.info(mdm);
    }
    render() {
        return html `<p> Hello, ${this.name} !</p>`;
    }
};
__decorate([
    property()
], Aaaa102018.prototype, "name", void 0);
Aaaa102018 = __decorate([
    customElement('aaaa-102018')
], Aaaa102018);
export { Aaaa102018 };
