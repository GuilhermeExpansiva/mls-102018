declare module "_102018_aaaa.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102018_aaaa" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class Aaaa102018 extends StateLitElement {
        name: string;
        firstUpdated(): Promise<void>;
        render(): any;
    }
}
declare module "_102018_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102018_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102018_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102018_project" {
    export const modules: any[];
}
